package com.bah.mcc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MccProjectDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(MccProjectDataApplication.class, args);
	}

}
