package com.bah.mcc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MccProjectDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
